﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureProject
{
    public class BookDataStructure
    {
        //to implement First Come First Serve basis
        public static Queue<Book> books = new Queue<Book>();
    }
}
